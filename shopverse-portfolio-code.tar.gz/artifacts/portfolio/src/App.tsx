import React from 'react';
import { AnimatePresence } from 'framer-motion';
import { LoadingScreen } from '@/components/LoadingScreen';
import { Cursor } from '@/components/Cursor';
import { ParticlesBackground } from '@/components/ParticlesBackground';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/sections/Hero';
import { About } from '@/components/sections/About';
import { Skills } from '@/components/sections/Skills';
import { Projects } from '@/components/sections/Projects';
import { Services } from '@/components/sections/Services';
import { Experience } from '@/components/sections/Experience';
import { Achievements } from '@/components/sections/Achievements';
import { Testimonials } from '@/components/sections/Testimonials';
import { Contact } from '@/components/sections/Contact';
import { Footer } from '@/components/sections/Footer';

export default function App() {
  const [loading, setLoading] = React.useState(true);

  return (
    <div className="bg-background min-h-screen text-foreground selection:bg-primary/30">
      <AnimatePresence>
        {loading && <LoadingScreen key="loading" onComplete={() => setLoading(false)} />}
      </AnimatePresence>
      <Cursor />
      <ParticlesBackground />
      
      {!loading && (
        <>
          <Navbar />
          <main className="relative">
            <Hero />
            <About />
            <Skills />
            <Projects />
            <Services />
            <Experience />
            <Achievements />
            <Testimonials />
            <Contact />
          </main>
          <Footer />
        </>
      )}
    </div>
  );
}
