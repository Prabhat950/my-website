import React from 'react';
import { motion } from 'framer-motion';

const achievements = [
  { value: '50+', label: 'Projects Completed' },
  { value: '20+', label: 'Happy Clients' },
  { value: '3+', label: 'Years Experience' },
  { value: '15+', label: 'Awards Won' },
];

export function Achievements() {
  return (
    <section className="py-20 relative z-10 border-y border-white/5 bg-background/30">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {achievements.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center"
            >
              <div className="text-4xl md:text-5xl font-bold text-gradient mb-2">{item.value}</div>
              <div className="text-muted-foreground text-sm uppercase tracking-wider">{item.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
