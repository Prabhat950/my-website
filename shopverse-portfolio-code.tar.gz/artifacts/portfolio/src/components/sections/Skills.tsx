import React from 'react';
import { motion } from 'framer-motion';

const skills = [
  { name: 'React', level: 95 },
  { name: 'Next.js', level: 90 },
  { name: 'TypeScript', level: 85 },
  { name: 'Node.js', level: 88 },
  { name: 'Python', level: 80 },
  { name: 'PostgreSQL', level: 85 },
  { name: 'MongoDB', level: 82 },
  { name: 'Tailwind CSS', level: 98 },
  { name: 'Figma', level: 90 },
  { name: 'Three.js', level: 75 },
  { name: 'Docker', level: 78 },
  { name: 'AWS', level: 70 },
];

export function Skills() {
  return (
    <section id="skills" className="py-32 relative z-10 bg-background/50">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Technical <span className="text-gradient">Arsenal</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A comprehensive overview of my technical capabilities and tools I use to build digital experiences.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass p-6 rounded-2xl relative overflow-hidden group"
            >
              <div className="flex justify-between items-center mb-4 relative z-10">
                <h3 className="font-semibold text-lg">{skill.name}</h3>
                <span className="text-primary font-mono">{skill.level}%</span>
              </div>
              <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden relative z-10">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${skill.level}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 1, delay: 0.5 + index * 0.1, ease: "easeOut" }}
                  className="h-full bg-gradient-to-r from-primary to-[#a78bfa] rounded-full"
                />
              </div>
              
              {/* Hover effect background */}
              <div className="absolute inset-0 bg-primary/5 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-in-out" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
