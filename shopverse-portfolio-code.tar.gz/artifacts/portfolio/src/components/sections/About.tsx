import React from 'react';
import { motion } from 'framer-motion';

const stats = [
  { value: '50+', label: 'Projects Completed' },
  { value: '3+', label: 'Years Experience' },
  { value: '20+', label: 'Happy Clients' },
  { value: '100%', label: 'Dedication' },
];

export function About() {
  return (
    <section id="about" className="py-32 relative z-10">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              About <span className="text-gradient">Me</span>
            </h2>
            <div className="space-y-6 text-lg text-muted-foreground">
              <p>
                Hi, I'm Prabhat Dubey, a passionate Full Stack Developer and UI/UX Designer who focuses on creating digital experiences that leave a lasting impact. I bridge the gap between design and engineering.
              </p>
              <p>
                My journey began with a curiosity about how things work on the internet, which quickly evolved into a deep-seated passion for crafting beautiful, functional, and user-centric applications.
              </p>
              <p>
                Whether I'm designing intuitive interfaces or architecting robust backend systems, my goal remains the same: to deliver exceptional products that solve real-world problems elegantly.
              </p>
            </div>
          </motion.div>

          <div className="grid grid-cols-2 gap-6">
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                className="glass-card p-8 rounded-2xl flex flex-col items-center justify-center text-center group hover:-translate-y-2 transition-transform duration-300"
              >
                <span className="text-4xl md:text-5xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {stat.value}
                </span>
                <span className="text-muted-foreground text-sm uppercase tracking-wider">
                  {stat.label}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
