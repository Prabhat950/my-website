import React from 'react';
import { ArrowUp } from 'lucide-react';
import { motion } from 'framer-motion';

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="py-12 border-t border-white/5 relative z-10 bg-background/80">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-center md:text-left">
            <h2 className="text-2xl font-bold tracking-tighter" style={{ fontFamily: 'var(--font-display)' }}>
              Prabhat Dubey
            </h2>
            <p className="text-sm text-muted-foreground mt-2">
              Building exceptional digital experiences.
            </p>
          </div>
          
          <div className="flex gap-6 text-sm text-muted-foreground font-medium">
            <a href="#about" className="hover:text-primary transition-colors">About</a>
            <a href="#projects" className="hover:text-primary transition-colors">Projects</a>
            <a href="#contact" className="hover:text-primary transition-colors">Contact</a>
          </div>

          <button
            onClick={scrollToTop}
            className="w-10 h-10 rounded-full glass flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/50 transition-colors group"
            aria-label="Back to top"
          >
            <motion.div
              animate={{ y: [0, -3, 0] }}
              transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
            >
              <ArrowUp size={18} />
            </motion.div>
          </button>
        </div>
        
        <div className="mt-12 pt-8 border-t border-white/5 text-center text-xs text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Prabhat Dubey. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
