import React from 'react';
import { motion } from 'framer-motion';
import { Code2, MonitorPlay, PenTool, LayoutTemplate, ShoppingCart, Zap } from 'lucide-react';

const services = [
  {
    title: 'Website Development',
    description: 'Custom, responsive websites built from scratch to perfectly match your brand and goals.',
    icon: MonitorPlay,
  },
  {
    title: 'Web Applications',
    description: 'Complex, scalable single-page applications and progressive web apps using modern frameworks.',
    icon: Code2,
  },
  {
    title: 'UI/UX Design',
    description: 'Intuitive, user-centered interfaces designed with a deep understanding of user behavior.',
    icon: PenTool,
  },
  {
    title: 'Landing Pages',
    description: 'High-converting landing pages optimized for marketing campaigns and product launches.',
    icon: LayoutTemplate,
  },
  {
    title: 'E-commerce Development',
    description: 'Robust online stores with secure payment gateways and seamless shopping experiences.',
    icon: ShoppingCart,
  },
  {
    title: 'Website Optimization',
    description: 'Performance tuning, SEO enhancement, and accessibility improvements for existing sites.',
    icon: Zap,
  },
];

export function Services() {
  return (
    <section id="services" className="py-32 relative z-10 bg-background/50">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            My <span className="text-gradient">Services</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Comprehensive digital solutions tailored to elevate your business.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass p-8 rounded-2xl group hover:border-primary/30 transition-colors duration-300"
            >
              <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform duration-300">
                <service.icon size={28} />
              </div>
              <h3 className="text-xl font-bold mb-3">{service.title}</h3>
              <p className="text-muted-foreground leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
