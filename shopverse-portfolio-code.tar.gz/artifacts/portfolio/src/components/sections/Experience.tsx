import React from 'react';
import { motion } from 'framer-motion';

const experience = [
  {
    role: 'Senior Full Stack Developer',
    company: 'Tech Innovators Inc.',
    period: '2022 - Present',
    description: 'Leading a team of developers in building enterprise-level web applications. Architected scalable solutions using React, Node.js, and AWS.',
  },
  {
    role: 'UI/UX Designer & Frontend Dev',
    company: 'Creative Digital Agency',
    period: '2020 - 2022',
    description: 'Designed and implemented high-conversion landing pages and interactive web experiences. Bridged the gap between design and engineering.',
  },
  {
    role: 'Junior Web Developer',
    company: 'Startup Solutions',
    period: '2019 - 2020',
    description: 'Developed responsive frontend interfaces and integrated RESTful APIs. Gained foundational experience in modern web development practices.',
  },
];

export function Experience() {
  return (
    <section id="experience" className="py-32 relative z-10">
      <div className="container mx-auto px-6 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Professional <span className="text-gradient">Experience</span>
          </h2>
          <p className="text-muted-foreground">My career journey so far.</p>
        </motion.div>

        <div className="relative">
          {/* Vertical Line */}
          <div className="absolute left-[15px] md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-primary/50 via-primary/20 to-transparent md:-translate-x-1/2" />

          {experience.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className={`relative flex flex-col md:flex-row gap-8 mb-12 ${
                index % 2 === 0 ? 'md:flex-row-reverse' : ''
              }`}
            >
              {/* Timeline Dot */}
              <div className="absolute left-[11px] md:left-1/2 top-1 w-2 h-2 rounded-full bg-primary ring-4 ring-background md:-translate-x-1/2" />

              <div className="md:w-1/2 pl-12 md:pl-0" />
              
              <div className={`md:w-1/2 pl-12 md:pl-0 ${index % 2 === 0 ? 'md:pr-12 md:text-right' : 'md:pl-12'}`}>
                <div className="glass p-6 rounded-2xl relative group hover:border-primary/30 transition-colors">
                  <span className="text-primary font-mono text-sm mb-2 block">{item.period}</span>
                  <h3 className="text-xl font-bold mb-1">{item.role}</h3>
                  <h4 className="text-muted-foreground text-sm mb-4">{item.company}</h4>
                  <p className="text-muted-foreground/80 leading-relaxed text-sm">
                    {item.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
