import React, { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { ExternalLink, Github } from 'lucide-react';

const projects = [
  {
    title: 'E-Commerce Platform',
    description: 'A full-featured e-commerce solution with modern architecture and real-time inventory.',
    tech: ['React', 'Node.js', 'MongoDB'],
    github: '#',
    live: '#',
  },
  {
    title: 'AI Dashboard',
    description: 'Analytics dashboard powered by machine learning for predictive business insights.',
    tech: ['Next.js', 'Python', 'TensorFlow'],
    github: '#',
    live: '#',
  },
  {
    title: 'Design System',
    description: 'Comprehensive component library and design system for enterprise applications.',
    tech: ['React', 'Storybook', 'Figma'],
    github: '#',
    live: '#',
  },
  {
    title: 'Real-time Chat App',
    description: 'Scalable messaging application with presence, typing indicators, and media sharing.',
    tech: ['Socket.io', 'Redis', 'Node.js'],
    github: '#',
    live: '#',
  },
  {
    title: 'Portfolio Builder',
    description: 'No-code portfolio generation tool for creatives with customizable templates.',
    tech: ['React', 'Tailwind', 'Framer Motion'],
    github: '#',
    live: '#',
  },
  {
    title: 'Task Manager Pro',
    description: 'Enterprise-grade project management tool with Kanban boards and Gantt charts.',
    tech: ['React', 'TypeScript', 'PostgreSQL'],
    github: '#',
    live: '#',
  },
];

function TiltCard({ project }: { project: typeof projects[0] }) {
  const ref = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["10deg", "-10deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-10deg", "10deg"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
      className="glass-card rounded-2xl p-8 h-full flex flex-col relative group overflow-hidden border-white/10"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
      
      <div style={{ transform: "translateZ(30px)" }} className="relative z-10 flex-grow">
        <h3 className="text-2xl font-bold mb-3">{project.title}</h3>
        <p className="text-muted-foreground mb-6">{project.description}</p>
      </div>

      <div style={{ transform: "translateZ(20px)" }} className="relative z-10 mt-auto">
        <div className="flex flex-wrap gap-2 mb-6">
          {project.tech.map(t => (
            <span key={t} className="text-xs px-3 py-1 rounded-full bg-white/5 border border-white/10 text-muted-foreground">
              {t}
            </span>
          ))}
        </div>
        
        <div className="flex items-center gap-4">
          <a href={project.github} className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-2 text-sm font-medium">
            <Github size={18} /> Code
          </a>
          <a href={project.live} className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-2 text-sm font-medium">
            <ExternalLink size={18} /> Live Demo
          </a>
        </div>
      </div>
    </motion.div>
  );
}

export function Projects() {
  return (
    <section id="projects" className="py-32 relative z-10">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Featured <span className="text-gradient">Work</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A selection of my recent projects, showcasing my expertise in building scalable, user-centric applications.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" style={{ perspective: "1000px" }}>
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <TiltCard project={project} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
