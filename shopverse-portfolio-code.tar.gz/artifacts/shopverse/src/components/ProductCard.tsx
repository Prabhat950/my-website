import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { Link } from "wouter";
import { Heart, ShoppingBag } from "lucide-react";
import { Button } from "./ui/button";
import { Product } from "@workspace/api-client-react";
import StarRating from "./StarRating";
import { useAddToCart, useAddToWishlist } from "@workspace/api-client-react";
import { toast } from "@/hooks/use-toast";

export default function ProductCard({ product }: { product: Product }) {
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["7.5deg", "-7.5deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-7.5deg", "7.5deg"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  const addToCart = useAddToCart();
  const addToWishlist = useAddToWishlist();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart.mutate({ data: { productId: product.id, quantity: 1 } }, {
      onSuccess: () => {
        toast({ title: "Added to cart", description: `${product.name} added to your cart.` });
      }
    });
  };

  const handleAddToWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToWishlist.mutate({ data: { productId: product.id } }, {
      onSuccess: () => {
        toast({ title: "Added to wishlist", description: `${product.name} saved for later.` });
      }
    });
  };

  return (
    <Link href={`/products/${product.id}`}>
      <motion.div
        className="group relative bg-card border border-border rounded-xl overflow-hidden shadow-sm hover:shadow-2xl hover:shadow-primary/20 transition-all duration-300 transform-gpu"
        style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        {product.originalPrice && product.originalPrice > product.price && (
          <div className="absolute top-3 left-3 z-10 bg-destructive text-destructive-foreground text-xs font-bold px-2 py-1 rounded-md">
            -{Math.round((1 - product.price / product.originalPrice) * 100)}%
          </div>
        )}
        
        <div className="absolute top-3 right-3 z-10 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity translate-x-4 group-hover:translate-x-0">
          <Button variant="secondary" size="icon" className="rounded-full shadow-md bg-background/80 backdrop-blur-sm hover:bg-primary hover:text-primary-foreground" onClick={handleAddToWishlist}>
            <Heart className="h-4 w-4" />
          </Button>
        </div>

        <div className="aspect-square w-full overflow-hidden bg-muted relative" style={{ transform: "translateZ(30px)" }}>
          <img 
            src={(product.images && product.images[0]) || "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&q=80"} 
            alt={product.name} 
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>

        <div className="p-4" style={{ transform: "translateZ(20px)" }}>
          <div className="text-xs text-muted-foreground mb-1 font-medium tracking-wide uppercase">{product.category}</div>
          <h3 className="font-semibold text-base line-clamp-1 group-hover:text-primary transition-colors">{product.name}</h3>
          
          <div className="flex items-center gap-2 mt-2">
            <StarRating rating={product.rating} count={product.reviewCount} />
          </div>

          <div className="flex items-end justify-between mt-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-foreground">${product.price.toFixed(2)}</span>
                {product.originalPrice && product.originalPrice > product.price && (
                  <span className="text-sm text-muted-foreground line-through">${product.originalPrice.toFixed(2)}</span>
                )}
              </div>
            </div>
            
            <Button size="sm" onClick={handleAddToCart} className="opacity-0 group-hover:opacity-100 transition-all -translate-y-2 group-hover:translate-y-0 rounded-full font-bold">
              <ShoppingBag className="h-4 w-4 mr-1" /> Add
            </Button>
          </div>
        </div>
      </motion.div>
    </Link>
  );
}
