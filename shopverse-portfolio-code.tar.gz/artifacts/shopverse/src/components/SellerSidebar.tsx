import { Link, useLocation } from "wouter";
import { LayoutDashboard, Package, PlusCircle, ShoppingBag, BarChart3, LogOut } from "lucide-react";
import { Button } from "./ui/button";
import ThemeToggle from "./ThemeToggle";

export default function SellerSidebar() {
  const [location] = useLocation();

  const links = [
    { href: "/seller", label: "Dashboard", icon: LayoutDashboard },
    { href: "/seller/products", label: "Products", icon: Package },
    { href: "/seller/add-product", label: "Add Product", icon: PlusCircle },
    { href: "/seller/orders", label: "Orders", icon: ShoppingBag },
    { href: "/seller/analytics", label: "Analytics", icon: BarChart3 },
  ];

  return (
    <aside className="w-64 h-screen fixed left-0 top-0 hidden md:flex flex-col bg-card border-r border-border z-40">
      <div className="h-16 flex items-center px-6 border-b border-border">
        <Link href="/" className="text-xl font-extrabold text-primary tracking-tighter">
          ShopVerse
        </Link>
        <span className="ml-2 text-xs font-medium text-muted-foreground uppercase tracking-widest bg-secondary/10 px-2 py-1 rounded-full">Seller</span>
      </div>

      <nav className="flex-1 py-6 px-4 space-y-2 overflow-y-auto">
        {links.map((link) => {
          const Icon = link.icon;
          const isActive = location === link.href;
          return (
            <Link key={link.href} href={link.href}>
              <Button
                variant={isActive ? "default" : "ghost"}
                className={`w-full justify-start gap-3 ${isActive ? "bg-primary text-primary-foreground" : "hover:bg-secondary/10 hover:text-primary"}`}
              >
                <Icon className="h-5 w-5" />
                {link.label}
              </Button>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border flex items-center justify-between">
        <ThemeToggle />
        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive">
          <LogOut className="h-5 w-5" />
        </Button>
      </div>
    </aside>
  );
}
