import { Link } from "wouter";
import { Search, ShoppingBag, Heart, User, Menu } from "lucide-react";
import ThemeToggle from "./ThemeToggle";
import { useGetCart, useGetWishlist } from "@workspace/api-client-react";
import { Button } from "./ui/button";

export default function Navbar() {
  const { data: cart } = useGetCart({ query: { enabled: true } });
  const { data: wishlist } = useGetWishlist({ query: { enabled: true } });

  const cartItemsCount = cart?.items?.reduce((acc, item) => acc + item.quantity, 0) || 0;
  const wishlistItemsCount = wishlist?.items?.length || 0;

  return (
    <header className="sticky top-0 z-50 w-full glass border-b border-border">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-6 w-6" />
          </Button>
          <Link href="/" className="text-2xl font-extrabold tracking-tighter text-primary">
            ShopVerse
          </Link>
        </div>

        <div className="hidden md:flex items-center flex-1 max-w-md mx-8 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="search"
            placeholder="Search everything, everywhere..."
            className="w-full h-10 pl-10 pr-4 rounded-full bg-secondary/10 border-transparent focus:bg-background focus:border-primary focus:ring-1 focus:ring-primary transition-all text-sm outline-none"
          />
        </div>

        <div className="flex items-center gap-2 md:gap-4">
          <ThemeToggle />
          
          <Link href="/wishlist">
            <Button variant="ghost" size="icon" className="relative hover:text-primary transition-colors">
              <Heart className="h-5 w-5" />
              {wishlistItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                  {wishlistItemsCount}
                </span>
              )}
            </Button>
          </Link>

          <Link href="/cart">
            <Button variant="ghost" size="icon" className="relative hover:text-primary transition-colors">
              <ShoppingBag className="h-5 w-5" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                  {cartItemsCount}
                </span>
              )}
            </Button>
          </Link>

          <div className="h-8 w-px bg-border mx-1 hidden md:block"></div>

          <Link href="/login" className="hidden md:flex">
            <Button variant="ghost" size="icon" className="hover:text-primary transition-colors">
              <User className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </header>
  );
}
