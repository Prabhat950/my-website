import { ReactNode } from "react";
import AdminSidebar from "@/components/AdminSidebar";

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex bg-background w-full">
      <AdminSidebar />
      <main className="flex-1 p-6 md:p-8 ml-0 md:ml-64 w-full">
        {children}
      </main>
    </div>
  );
}
