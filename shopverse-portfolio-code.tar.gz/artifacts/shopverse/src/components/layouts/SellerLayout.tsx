import { ReactNode } from "react";
import SellerSidebar from "@/components/SellerSidebar";

export default function SellerLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex bg-background w-full">
      <SellerSidebar />
      <main className="flex-1 p-6 md:p-8 ml-0 md:ml-64 w-full">
        {children}
      </main>
    </div>
  );
}
