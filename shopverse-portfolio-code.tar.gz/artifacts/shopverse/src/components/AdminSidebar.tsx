import { Link, useLocation } from "wouter";
import { LayoutDashboard, Users, Store, Package, Image as ImageIcon, Ticket, LogOut } from "lucide-react";
import { Button } from "./ui/button";
import ThemeToggle from "./ThemeToggle";

export default function AdminSidebar() {
  const [location] = useLocation();

  const links = [
    { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
    { href: "/admin/users", label: "Users", icon: Users },
    { href: "/admin/sellers", label: "Sellers", icon: Store },
    { href: "/admin/products", label: "Products", icon: Package },
    { href: "/admin/banners", label: "Banners", icon: ImageIcon },
    { href: "/admin/coupons", label: "Coupons", icon: Ticket },
  ];

  return (
    <aside className="w-64 h-screen fixed left-0 top-0 hidden md:flex flex-col bg-card border-r border-border z-40">
      <div className="h-16 flex items-center px-6 border-b border-border">
        <Link href="/" className="text-xl font-extrabold text-primary tracking-tighter">
          ShopVerse
        </Link>
        <span className="ml-2 text-xs font-medium text-destructive uppercase tracking-widest bg-destructive/10 text-destructive px-2 py-1 rounded-full">Admin</span>
      </div>

      <nav className="flex-1 py-6 px-4 space-y-2 overflow-y-auto">
        {links.map((link) => {
          const Icon = link.icon;
          const isActive = location === link.href;
          return (
            <Link key={link.href} href={link.href}>
              <Button
                variant={isActive ? "default" : "ghost"}
                className={`w-full justify-start gap-3 ${isActive ? "bg-primary text-primary-foreground" : "hover:bg-secondary/10 hover:text-primary"}`}
              >
                <Icon className="h-5 w-5" />
                {link.label}
              </Button>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border flex items-center justify-between">
        <ThemeToggle />
        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive">
          <LogOut className="h-5 w-5" />
        </Button>
      </div>
    </aside>
  );
}
