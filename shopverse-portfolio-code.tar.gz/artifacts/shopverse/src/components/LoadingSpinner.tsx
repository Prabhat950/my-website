import { Loader2 } from "lucide-react";

export default function LoadingSpinner() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] w-full gap-4">
      <div className="relative">
        <div className="absolute inset-0 rounded-full blur-xl bg-primary/30 animate-pulse"></div>
        <Loader2 className="w-12 h-12 text-primary animate-spin relative z-10" />
      </div>
      <p className="text-sm font-medium text-muted-foreground animate-pulse tracking-widest uppercase">Loading ShopVerse</p>
    </div>
  );
}
