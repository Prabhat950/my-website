import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import NotFound from "@/pages/not-found";

import CustomerLayout from "@/components/layouts/CustomerLayout";
import SellerLayout from "@/components/layouts/SellerLayout";
import AdminLayout from "@/components/layouts/AdminLayout";
import CustomCursor from "@/components/CustomCursor";

import CustomerStorefront from "@/pages/customer/CustomerStorefront";
import ProductsListing from "@/pages/customer/ProductsListing";
import ProductDetail from "@/pages/customer/ProductDetail";
import CartPage from "@/pages/customer/CartPage";
import WishlistPage from "@/pages/customer/WishlistPage";
import CheckoutPage from "@/pages/customer/CheckoutPage";
import OrdersPage from "@/pages/customer/OrdersPage";

import SellerDashboard from "@/pages/seller/SellerDashboard";
import SellerProducts from "@/pages/seller/SellerProducts";
import AddProductForm from "@/pages/seller/AddProductForm";
import SellerOrders from "@/pages/seller/SellerOrders";
import SellerAnalytics from "@/pages/seller/SellerAnalytics";

import AdminDashboard from "@/pages/admin/AdminDashboard";
import AdminUsers from "@/pages/admin/AdminUsers";
import AdminSellers from "@/pages/admin/AdminSellers";
import AdminProducts from "@/pages/admin/AdminProducts";
import AdminBanners from "@/pages/admin/AdminBanners";
import AdminCoupons from "@/pages/admin/AdminCoupons";

import LoginPage from "@/pages/auth/LoginPage";
import RegisterPage from "@/pages/auth/RegisterPage";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/login" component={LoginPage} />
      <Route path="/register" component={RegisterPage} />

      <Route path="/seller*">
        <SellerLayout>
          <Switch>
            <Route path="/seller" component={SellerDashboard} />
            <Route path="/seller/products" component={SellerProducts} />
            <Route path="/seller/add-product" component={AddProductForm} />
            <Route path="/seller/orders" component={SellerOrders} />
            <Route path="/seller/analytics" component={SellerAnalytics} />
            <Route component={NotFound} />
          </Switch>
        </SellerLayout>
      </Route>

      <Route path="/admin*">
        <AdminLayout>
          <Switch>
            <Route path="/admin" component={AdminDashboard} />
            <Route path="/admin/users" component={AdminUsers} />
            <Route path="/admin/sellers" component={AdminSellers} />
            <Route path="/admin/products" component={AdminProducts} />
            <Route path="/admin/banners" component={AdminBanners} />
            <Route path="/admin/coupons" component={AdminCoupons} />
            <Route component={NotFound} />
          </Switch>
        </AdminLayout>
      </Route>

      <Route path="*">
        <CustomerLayout>
          <Switch>
            <Route path="/" component={CustomerStorefront} />
            <Route path="/products" component={ProductsListing} />
            <Route path="/products/:id" component={ProductDetail} />
            <Route path="/cart" component={CartPage} />
            <Route path="/wishlist" component={WishlistPage} />
            <Route path="/checkout" component={CheckoutPage} />
            <Route path="/orders" component={OrdersPage} />
            <Route component={NotFound} />
          </Switch>
        </CustomerLayout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <CustomCursor />
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
