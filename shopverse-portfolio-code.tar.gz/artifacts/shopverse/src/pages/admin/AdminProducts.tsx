import { useState } from "react";
import { useListProducts, useApproveProduct } from "@workspace/api-client-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle2 } from "lucide-react";
import LoadingSpinner from "@/components/LoadingSpinner";
import { toast } from "@/hooks/use-toast";

export default function AdminProducts() {
  const [filter, setFilter] = useState("all");
  const { data: productsData, isLoading, refetch } = useListProducts();
  const approveProduct = useApproveProduct();

  const handleApprove = (id: number) => {
    approveProduct.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Product approved" });
        refetch();
      }
    });
  };

  if (isLoading) return <LoadingSpinner />;

  let displayedProducts = productsData?.products || [];
  if (filter === "pending") displayedProducts = displayedProducts.filter(p => !p.approved);
  if (filter === "approved") displayedProducts = displayedProducts.filter(p => p.approved);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Product Approvals</h1>
          <p className="text-muted-foreground">Review and approve products for the marketplace.</p>
        </div>
        <div className="w-full sm:w-48">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Products</SelectItem>
              <SelectItem value="pending">Pending Approval</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl p-4">
        <div className="rounded-md border border-border overflow-hidden">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead>Product</TableHead>
                <TableHead>Seller ID</TableHead>
                <TableHead>Price</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {displayedProducts.map(product => (
                <TableRow key={product.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-muted rounded overflow-hidden">
                        <img src={(product.images && product.images[0]) || `https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=100&q=80&sig=${product.id}`} alt="" className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <div className="font-semibold">{product.name}</div>
                        <div className="text-xs text-muted-foreground">{product.category}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{product.sellerId}</TableCell>
                  <TableCell>${product.price.toFixed(2)}</TableCell>
                  <TableCell className="text-center">
                    <Badge variant={product.approved ? "default" : "secondary"} className={product.approved ? "bg-green-500/10 text-green-500 hover:bg-green-500/20 border-none" : "bg-amber-500/10 text-amber-500 hover:bg-amber-500/20 border-none"}>
                      {product.approved ? "Approved" : "Pending"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    {!product.approved && (
                      <Button size="sm" onClick={() => handleApprove(product.id)}>
                        <CheckCircle2 className="mr-1 h-4 w-4" /> Approve
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {displayedProducts.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    No products match the selected filter.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}