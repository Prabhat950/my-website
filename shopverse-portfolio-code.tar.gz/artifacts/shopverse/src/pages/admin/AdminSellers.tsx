import { useListSellers, useVerifySeller } from "@workspace/api-client-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";
import LoadingSpinner from "@/components/LoadingSpinner";
import { toast } from "@/hooks/use-toast";

export default function AdminSellers() {
  const { data: sellersData, isLoading, refetch } = useListSellers();
  const verifySeller = useVerifySeller();

  const handleVerify = (id: number) => {
    verifySeller.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Seller verified successfully" });
        refetch();
      }
    });
  };

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight">Sellers</h1>
        <p className="text-muted-foreground">Manage seller accounts and verifications.</p>
      </div>

      <div className="bg-card border border-border rounded-xl p-4">
        <div className="rounded-md border border-border overflow-hidden">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead>Shop Name</TableHead>
                <TableHead>Rating</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sellersData?.items?.map(seller => (
                <TableRow key={seller.id}>
                  <TableCell>
                    <div className="font-bold">{seller.shopName}</div>
                    <div className="text-xs text-muted-foreground">User ID: {seller.userId}</div>
                  </TableCell>
                  <TableCell>{seller.rating.toFixed(1)} / 5.0</TableCell>
                  <TableCell className="text-center">
                    {seller.isVerified ? (
                      <Badge className="bg-green-500/10 text-green-500 hover:bg-green-500/20 border-none">Verified</Badge>
                    ) : (
                      <Badge variant="secondary" className="bg-amber-500/10 text-amber-500 hover:bg-amber-500/20 border-none">Pending Verification</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    {!seller.isVerified && (
                      <Button size="sm" onClick={() => handleVerify(seller.id)} disabled={verifySeller.isPending}>
                        <CheckCircle2 className="mr-1 h-4 w-4" /> Verify
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}