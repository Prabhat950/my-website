import { useState } from "react";
import { useListCoupons, useCreateCoupon } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Ticket } from "lucide-react";
import LoadingSpinner from "@/components/LoadingSpinner";
import { toast } from "@/hooks/use-toast";

export default function AdminCoupons() {
  const { data: couponsData, isLoading, refetch } = useListCoupons();
  const createCoupon = useCreateCoupon();
  const [open, setOpen] = useState(false);

  const [form, setForm] = useState({
    code: "",
    discountType: "PERCENTAGE",
    discountValue: "",
    minOrderAmount: "",
    maxUsage: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createCoupon.mutate({
      data: {
        code: form.code.toUpperCase(),
        discountType: form.discountType,
        discountValue: parseFloat(form.discountValue),
        minOrderAmount: form.minOrderAmount ? parseFloat(form.minOrderAmount) : undefined,
        maxUsage: form.maxUsage ? parseInt(form.maxUsage, 10) : undefined,
        isActive: true,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days from now
      }
    }, {
      onSuccess: () => {
        toast({ title: "Coupon created successfully" });
        setOpen(false);
        setForm({ code: "", discountType: "PERCENTAGE", discountValue: "", minOrderAmount: "", maxUsage: "" });
        refetch();
      }
    });
  };

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Coupons</h1>
          <p className="text-muted-foreground">Create and manage discount codes.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="mr-2 h-4 w-4" /> Create Coupon</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Coupon</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Coupon Code</Label>
                <Input required value={form.code} onChange={e => setForm({...form, code: e.target.value.toUpperCase()})} placeholder="e.g. SUMMER20" />
              </div>
              <div className="space-y-2">
                <Label>Discount Value</Label>
                <Input type="number" required value={form.discountValue} onChange={e => setForm({...form, discountValue: e.target.value})} placeholder="e.g. 20" />
              </div>
              <div className="space-y-2">
                <Label>Minimum Order Amount ($) (Optional)</Label>
                <Input type="number" value={form.minOrderAmount} onChange={e => setForm({...form, minOrderAmount: e.target.value})} />
              </div>
              <Button type="submit" className="w-full" disabled={createCoupon.isPending}>Create</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-card border border-border rounded-xl p-4">
        <div className="rounded-md border border-border overflow-hidden">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Discount</TableHead>
                <TableHead>Min Order</TableHead>
                <TableHead className="text-center">Uses</TableHead>
                <TableHead>Expires</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {couponsData?.items?.map(coupon => (
                <TableRow key={coupon.id}>
                  <TableCell>
                    <div className="flex items-center gap-2 font-mono font-bold text-primary">
                      <Ticket className="h-4 w-4" /> {coupon.code}
                    </div>
                  </TableCell>
                  <TableCell>
                    {coupon.discountType === 'PERCENTAGE' ? `${coupon.discountValue}%` : `$${coupon.discountValue}`}
                  </TableCell>
                  <TableCell>{coupon.minOrderAmount ? `$${coupon.minOrderAmount}` : 'None'}</TableCell>
                  <TableCell className="text-center">{coupon.currentUsage} / {coupon.maxUsage || '∞'}</TableCell>
                  <TableCell>{new Date(coupon.expiresAt).toLocaleDateString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}