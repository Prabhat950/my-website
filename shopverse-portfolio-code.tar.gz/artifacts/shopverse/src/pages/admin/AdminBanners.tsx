import { useState } from "react";
import { useListBanners, useCreateBanner } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus } from "lucide-react";
import LoadingSpinner from "@/components/LoadingSpinner";
import { toast } from "@/hooks/use-toast";

export default function AdminBanners() {
  const { data: bannersData, isLoading, refetch } = useListBanners();
  const createBanner = useCreateBanner();
  const [open, setOpen] = useState(false);

  const [form, setForm] = useState({
    title: "",
    imageUrl: "",
    linkUrl: "",
    position: "HERO"
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createBanner.mutate({
      data: {
        title: form.title,
        imageUrl: form.imageUrl,
        linkUrl: form.linkUrl,
        position: form.position,
        isActive: true
      }
    }, {
      onSuccess: () => {
        toast({ title: "Banner created successfully" });
        setOpen(false);
        setForm({ title: "", imageUrl: "", linkUrl: "", position: "HERO" });
        refetch();
      }
    });
  };

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Banners</h1>
          <p className="text-muted-foreground">Manage promotional banners across the site.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="mr-2 h-4 w-4" /> Add Banner</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Banner</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Title</Label>
                <Input required value={form.title} onChange={e => setForm({...form, title: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Image URL</Label>
                <Input required value={form.imageUrl} onChange={e => setForm({...form, imageUrl: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Link URL</Label>
                <Input required value={form.linkUrl} onChange={e => setForm({...form, linkUrl: e.target.value})} />
              </div>
              <Button type="submit" className="w-full" disabled={createBanner.isPending}>Submit</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {bannersData?.items?.map(banner => (
          <div key={banner.id} className="border border-border rounded-xl overflow-hidden bg-card">
            <div className="aspect-[21/9] bg-muted w-full relative">
              <img src={banner.imageUrl} alt={banner.title} className="w-full h-full object-cover" />
              <Badge className="absolute top-2 right-2">{banner.position}</Badge>
            </div>
            <div className="p-4">
              <h3 className="font-bold text-lg mb-1">{banner.title}</h3>
              <p className="text-sm text-muted-foreground truncate">{banner.linkUrl}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}