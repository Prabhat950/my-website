import { useListOrders } from "@workspace/api-client-react";
import { Package, Clock, Truck, CheckCircle2, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import LoadingSpinner from "@/components/LoadingSpinner";
import { motion } from "framer-motion";
import { Link } from "wouter";

export default function OrdersPage() {
  // Mock customerId 1
  const { data: ordersData, isLoading } = useListOrders({ customerId: 1 });

  if (isLoading) return <LoadingSpinner />;

  const orders = ordersData?.items || [];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PENDING': return <Clock className="h-4 w-4" />;
      case 'PROCESSING': return <Package className="h-4 w-4" />;
      case 'SHIPPED': return <Truck className="h-4 w-4" />;
      case 'DELIVERED': return <CheckCircle2 className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING': return 'bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20';
      case 'PROCESSING': return 'bg-blue-500/10 text-blue-500 hover:bg-blue-500/20';
      case 'SHIPPED': return 'bg-purple-500/10 text-purple-500 hover:bg-purple-500/20';
      case 'DELIVERED': return 'bg-green-500/10 text-green-500 hover:bg-green-500/20';
      default: return 'bg-gray-500/10 text-gray-500 hover:bg-gray-500/20';
    }
  };

  if (orders.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 flex flex-col items-center justify-center min-h-[60vh] text-center">
        <div className="w-24 h-24 bg-secondary/10 rounded-full flex items-center justify-center mb-6">
          <Package className="h-10 w-10 text-primary" />
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight mb-4">No orders yet</h1>
        <p className="text-muted-foreground mb-8 max-w-md">You haven't placed any orders yet. Start shopping to see your orders here.</p>
        <Link href="/products">
          <Button size="lg" className="rounded-full px-8 font-bold">
            Explore Products
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <h1 className="text-3xl font-extrabold tracking-tight mb-8">Order History</h1>
      
      <div className="space-y-6">
        {orders.map((order, i) => (
          <motion.div
            key={order.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="border border-border bg-card rounded-2xl overflow-hidden"
          >
            <div className="p-4 sm:p-6 border-b border-border bg-muted/30 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex flex-wrap gap-x-8 gap-y-2 text-sm">
                <div>
                  <div className="text-muted-foreground font-medium mb-1">Order Placed</div>
                  <div className="font-semibold">{new Date(order.createdAt).toLocaleDateString()}</div>
                </div>
                <div>
                  <div className="text-muted-foreground font-medium mb-1">Total</div>
                  <div className="font-semibold">${order.totalAmount.toFixed(2)}</div>
                </div>
                <div>
                  <div className="text-muted-foreground font-medium mb-1">Order ID</div>
                  <div className="font-semibold">#{order.id.toString().padStart(6, '0')}</div>
                </div>
              </div>
              
              <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
                <Badge variant="secondary" className={`${getStatusColor(order.status)} border-none px-3 py-1 flex items-center gap-1.5`}>
                  {getStatusIcon(order.status)}
                  {order.status}
                </Badge>
                <Button variant="outline" size="sm" className="font-semibold">
                  Track Order
                </Button>
              </div>
            </div>
            
            <div className="p-4 sm:p-6">
              <div className="space-y-4">
                {order.items?.map(item => {
                  const price = (item.productId * 10) + 49.99; // Mock price
                  return (
                    <div key={item.id} className="flex gap-4 items-center">
                      <div className="w-20 h-20 bg-muted rounded-lg overflow-hidden shrink-0">
                        <img src={`https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=150&q=80&sig=${item.productId}`} alt="Product" className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-base line-clamp-1 hover:text-primary transition-colors cursor-pointer">
                          Premium Product #{item.productId}
                        </h4>
                        <div className="text-sm text-muted-foreground mt-1">Quantity: {item.quantity}</div>
                      </div>
                      <div className="text-right font-bold whitespace-nowrap">
                        ${(price * item.quantity).toFixed(2)}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}