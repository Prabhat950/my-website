import { motion } from "framer-motion";
import { Link } from "wouter";
import { Search, ArrowRight, ShieldCheck, Zap, Globe2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useListBanners, useListFeaturedProducts, useListRecommendations } from "@workspace/api-client-react";
import ProductCard from "@/components/ProductCard";
import LoadingSpinner from "@/components/LoadingSpinner";

const categories = [
  "Electronics", "Fashion", "Home & Kitchen", "Sports", "Beauty", "Books", "Automotive", "Toys"
];

export default function CustomerStorefront() {
  const { data: banners, isLoading: loadingBanners } = useListBanners();
  const { data: featuredProducts, isLoading: loadingFeatured } = useListFeaturedProducts();
  const { data: recommendedProducts, isLoading: loadingRecommendations } = useListRecommendations({});

  if (loadingBanners || loadingFeatured || loadingRecommendations) {
    return <LoadingSpinner />;
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="w-full flex flex-col"
    >
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex flex-col items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-secondary/20 z-0"></div>
        
        {/* Animated Particles/Orbs */}
        <motion.div 
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[120px] mix-blend-screen"
          animate={{ x: [0, 50, 0], y: [0, -50, 0] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="absolute bottom-1/4 right-1/4 w-[30rem] h-[30rem] bg-secondary/20 rounded-full blur-[120px] mix-blend-screen"
          animate={{ x: [0, -50, 0], y: [0, 50, 0] }}
          transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
        />

        <div className="container relative z-10 mx-auto px-4 text-center">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h1 className="text-6xl md:text-8xl font-extrabold tracking-tighter mb-6 bg-clip-text text-transparent bg-gradient-to-r from-foreground via-foreground to-primary">
              ShopVerse
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-10 max-w-2xl mx-auto font-medium">
              Shop Everything, Everywhere. The ultra-premium destination for curated goods.
            </p>
          </motion.div>

          <motion.div 
            className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-3xl mx-auto mb-16"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="relative w-full max-w-lg">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <input 
                type="text" 
                placeholder="Search for premium products..." 
                className="w-full h-14 pl-12 pr-4 rounded-full bg-card/80 backdrop-blur-md border border-border focus:border-primary focus:ring-2 focus:ring-primary shadow-2xl outline-none transition-all text-lg"
              />
            </div>
            <Link href="/products">
              <Button size="lg" className="h-14 px-8 rounded-full text-base font-bold group shadow-[0_0_40px_-10px_hsl(var(--primary))] hover:shadow-[0_0_60px_-10px_hsl(var(--primary))] transition-all duration-300">
                Explore <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </motion.div>

          <motion.div 
            className="flex flex-wrap justify-center gap-3"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            {categories.map((cat, i) => (
              <Link key={cat} href={`/products?category=${encodeURIComponent(cat)}`}>
                <span className="px-4 py-2 rounded-full bg-secondary/10 border border-secondary/20 text-sm font-medium hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all cursor-pointer inline-block">
                  {cat}
                </span>
              </Link>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="py-12 border-y border-border bg-card/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center divide-y md:divide-y-0 md:divide-x divide-border">
            <div className="flex flex-col items-center justify-center p-4">
              <Globe2 className="h-8 w-8 text-primary mb-3" />
              <div className="text-3xl font-extrabold text-foreground">10M+</div>
              <div className="text-sm text-muted-foreground uppercase tracking-wider font-semibold">Premium Products</div>
            </div>
            <div className="flex flex-col items-center justify-center p-4">
              <ShieldCheck className="h-8 w-8 text-secondary mb-3" />
              <div className="text-3xl font-extrabold text-foreground">500K+</div>
              <div className="text-sm text-muted-foreground uppercase tracking-wider font-semibold">Verified Sellers</div>
            </div>
            <div className="flex flex-col items-center justify-center p-4">
              <Zap className="h-8 w-8 text-amber-500 mb-3" />
              <div className="text-3xl font-extrabold text-foreground">50M+</div>
              <div className="text-sm text-muted-foreground uppercase tracking-wider font-semibold">Happy Customers</div>
            </div>
          </div>
        </div>
      </section>

      {/* Trending Products */}
      <section className="py-24 container mx-auto px-4">
        <div className="flex items-end justify-between mb-12">
          <div>
            <h2 className="text-4xl font-extrabold tracking-tight mb-2">Trending Now</h2>
            <p className="text-muted-foreground text-lg">The most coveted items this week.</p>
          </div>
          <Link href="/products?sort=featured">
            <Button variant="ghost" className="hover:text-primary group">
              View All <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {featuredProducts?.slice(0, 4).map((product, i) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <ProductCard product={product} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* AI Recommendations */}
      <section className="py-24 bg-card/30 border-y border-border">
        <div className="container mx-auto px-4">
          <div className="mb-12">
            <h2 className="text-4xl font-extrabold tracking-tight mb-2 bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">For You</h2>
            <p className="text-muted-foreground text-lg">AI-curated selection based on your taste.</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {recommendedProducts?.slice(0, 5).map((product, i) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </motion.div>
  );
}
