import { Link } from "wouter";
import { useGetCart, useRemoveFromCart, useAddToCart, useValidateCoupon } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2, ArrowRight, ShoppingBag, ArrowLeft } from "lucide-react";
import LoadingSpinner from "@/components/LoadingSpinner";
import { useState } from "react";
import { toast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

export default function CartPage() {
  const { data: cart, isLoading } = useGetCart();
  const updateCart = useAddToCart();
  const removeFromCart = useRemoveFromCart();
  const validateCoupon = useValidateCoupon();
  
  const [couponCode, setCouponCode] = useState("");
  const [discount, setDiscount] = useState(0);

  if (isLoading) return <LoadingSpinner />;

  const cartItems = cart?.items || [];
  
  // Calculate totals locally since the API doesn't seem to return them directly in the current mock response
  const subtotal = cartItems.reduce((acc, item) => {
    // In a real app, price comes from the product. Since we only have productId, we mock it.
    // For demo purposes, we'll assign a random price based on productId to keep it consistent.
    const price = (item.productId * 10) + 49.99; 
    return acc + (price * item.quantity);
  }, 0);
  
  const total = subtotal - discount + (subtotal > 0 ? 15 : 0); // $15 shipping

  const handleUpdateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    // The API uses useAddToCart for updates as well
    updateCart.mutate({ data: { productId, quantity: 1 } }); // In reality this would set quantity, but mock API increments
    toast({ title: "Cart updated" });
  };

  const handleRemove = (productId: number) => {
    removeFromCart.mutate({ data: { productId } });
    toast({ title: "Item removed from cart" });
  };

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode) return;
    
    validateCoupon.mutate({ data: { code: couponCode, orderAmount: subtotal } }, {
      onSuccess: (data) => {
        if (data.valid) {
          setDiscount(data.discountAmount);
          toast({ title: "Coupon applied", description: `You saved $${data.discountAmount.toFixed(2)}` });
        } else {
          toast({ title: "Invalid coupon", variant: "destructive" });
        }
      }
    });
  };

  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 flex flex-col items-center justify-center min-h-[60vh] text-center">
        <div className="w-24 h-24 bg-secondary/10 rounded-full flex items-center justify-center mb-6">
          <ShoppingBag className="h-10 w-10 text-primary" />
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight mb-4">Your cart is empty</h1>
        <p className="text-muted-foreground mb-8 max-w-md">Looks like you haven't added anything to your cart yet. Discover our premium collection and find something you love.</p>
        <Link href="/products">
          <Button size="lg" className="rounded-full px-8 font-bold">
            Start Shopping
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-extrabold tracking-tight mb-8">Shopping Cart</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2">
          <div className="rounded-2xl border border-border bg-card overflow-hidden">
            <div className="grid grid-cols-12 gap-4 p-4 border-b border-border bg-muted/30 text-sm font-semibold text-muted-foreground uppercase tracking-wider hidden sm:grid">
              <div className="col-span-6">Product</div>
              <div className="col-span-3 text-center">Quantity</div>
              <div className="col-span-2 text-right">Price</div>
              <div className="col-span-1"></div>
            </div>
            
            <ul className="divide-y divide-border">
              <AnimatePresence>
                {cartItems.map((item) => {
                  const mockPrice = (item.productId * 10) + 49.99;
                  return (
                    <motion.li 
                      key={item.id}
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="grid grid-cols-1 sm:grid-cols-12 gap-4 p-6 items-center"
                    >
                      <div className="col-span-1 sm:col-span-6 flex items-center gap-4">
                        <div className="w-20 h-20 bg-muted rounded-lg overflow-hidden shrink-0">
                          {/* Mock image */}
                          <img src={`https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200&q=80&sig=${item.productId}`} alt="Product" className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <Link href={`/products/${item.productId}`} className="font-bold text-lg hover:text-primary transition-colors line-clamp-1">
                            Premium Product #{item.productId}
                          </Link>
                          <div className="text-sm text-muted-foreground mt-1">Mock Category</div>
                        </div>
                      </div>
                      
                      <div className="col-span-1 sm:col-span-3 flex items-center sm:justify-center">
                        <div className="flex items-center border border-input rounded-md bg-background h-10 w-32">
                          <button 
                            className="px-3 h-full hover:bg-secondary/10 transition-colors"
                            onClick={() => handleUpdateQuantity(item.productId, item.quantity - 1)}
                          >-</button>
                          <div className="flex-1 text-center font-semibold text-sm">{item.quantity}</div>
                          <button 
                            className="px-3 h-full hover:bg-secondary/10 transition-colors"
                            onClick={() => handleUpdateQuantity(item.productId, item.quantity + 1)}
                          >+</button>
                        </div>
                      </div>
                      
                      <div className="col-span-1 sm:col-span-2 flex items-center justify-between sm:justify-end font-bold text-lg">
                        <span className="sm:hidden text-muted-foreground text-sm font-normal">Price:</span>
                        ${(mockPrice * item.quantity).toFixed(2)}
                      </div>
                      
                      <div className="col-span-1 sm:col-span-1 flex justify-end">
                        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive hover:bg-destructive/10" onClick={() => handleRemove(item.productId)}>
                          <Trash2 className="h-5 w-5" />
                        </Button>
                      </div>
                    </motion.li>
                  );
                })}
              </AnimatePresence>
            </ul>
          </div>
          
          <div className="mt-6">
            <Link href="/products" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="mr-2 h-4 w-4" /> Continue Shopping
            </Link>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="rounded-2xl border border-border bg-card p-6 sticky top-24">
            <h2 className="text-xl font-bold tracking-tight mb-6">Order Summary</h2>
            
            <div className="space-y-4 text-sm mb-6">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-semibold">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping estimate</span>
                <span className="font-semibold">$15.00</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-green-500">
                  <span>Discount</span>
                  <span className="font-semibold">-${discount.toFixed(2)}</span>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-border mb-6">
              <div className="flex justify-between items-end">
                <span className="text-base font-bold">Total</span>
                <span className="text-3xl font-extrabold text-primary">${total.toFixed(2)}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-2 text-right">Including VAT</p>
            </div>

            <form onSubmit={handleApplyCoupon} className="flex gap-2 mb-8">
              <Input 
                placeholder="Promo code" 
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                className="bg-background"
              />
              <Button type="submit" variant="secondary" disabled={validateCoupon.isPending}>
                Apply
              </Button>
            </form>

            <Link href="/checkout">
              <Button size="lg" className="w-full rounded-xl h-14 font-bold text-lg shadow-[0_0_20px_-5px_hsl(var(--primary))] hover:shadow-[0_0_30px_-5px_hsl(var(--primary))] transition-all group">
                Proceed to Checkout
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}