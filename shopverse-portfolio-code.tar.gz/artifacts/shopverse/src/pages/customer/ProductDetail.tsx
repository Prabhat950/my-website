import { useState } from "react";
import { useParams, Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useGetProduct, useListReviews, useCreateReview, useListRecommendations, useAddToCart, useAddToWishlist } from "@workspace/api-client-react";
import LoadingSpinner from "@/components/LoadingSpinner";
import StarRating from "@/components/StarRating";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { ShoppingBag, Heart, Share2, ChevronRight, Check, Package, RotateCcw, Truck } from "lucide-react";

export default function ProductDetail() {
  const params = useParams();
  const productId = parseInt(params.id || "0", 10);
  
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: "" });

  const { data: product, isLoading: loadingProduct } = useGetProduct(productId);
  const { data: reviews, isLoading: loadingReviews } = useListReviews({ productId });
  const { data: recommendations } = useListRecommendations({ category: product?.category });
  
  const addToCart = useAddToCart();
  const addToWishlist = useAddToWishlist();
  const createReview = useCreateReview();

  if (loadingProduct) return <LoadingSpinner />;
  if (!product) return <div className="p-8 text-center">Product not found</div>;

  const handleAddToCart = () => {
    addToCart.mutate({ data: { productId, quantity } }, {
      onSuccess: () => {
        toast({ title: "Added to cart", description: `${quantity}x ${product.name} added to your cart.` });
      }
    });
  };

  const handleAddToWishlist = () => {
    addToWishlist.mutate({ data: { productId } }, {
      onSuccess: () => {
        toast({ title: "Added to wishlist", description: `${product.name} saved for later.` });
      }
    });
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createReview.mutate({ data: { productId, ...reviewForm } }, {
      onSuccess: () => {
        toast({ title: "Review submitted", description: "Thank you for your feedback!" });
        setReviewForm({ rating: 5, comment: "" });
      }
    });
  };

  const images = product.images && product.images.length > 0 
    ? product.images 
    : ["https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80"];
  const discountPct = product.originalPrice && product.originalPrice > product.price
    ? Math.round((1 - product.price / product.originalPrice) * 100) : 0;

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <nav className="flex items-center text-sm text-muted-foreground mb-8">
        <Link href="/" className="hover:text-primary transition-colors">Home</Link>
        <ChevronRight className="h-4 w-4 mx-2" />
        <Link href={`/products?category=${product.category}`} className="hover:text-primary transition-colors">{product.category}</Link>
        <ChevronRight className="h-4 w-4 mx-2" />
        <span className="text-foreground truncate max-w-[200px] sm:max-w-none">{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
        {/* Images */}
        <div className="space-y-4">
          <motion.div 
            className="aspect-square bg-card rounded-2xl overflow-hidden border border-border relative group"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <AnimatePresence mode="wait">
              <motion.img
                key={selectedImage}
                src={images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
              />
            </AnimatePresence>
            {discountPct > 0 && (
              <div className="absolute top-4 left-4 bg-destructive text-destructive-foreground font-bold px-3 py-1 rounded-md">
                -{discountPct}% OFF
              </div>
            )}
          </motion.div>
          
          <div className="flex gap-4 overflow-x-auto pb-2">
            {images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedImage(idx)}
                className={`shrink-0 w-24 h-24 rounded-lg overflow-hidden border-2 transition-all ${selectedImage === idx ? 'border-primary ring-2 ring-primary/30 ring-offset-2 ring-offset-background' : 'border-transparent opacity-70 hover:opacity-100'}`}
              >
                <img src={img} alt={`${product.name} ${idx + 1}`} className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="flex flex-col">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="text-sm font-semibold text-primary tracking-widest uppercase mb-2">{product.category}</div>
            <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight mb-4">{product.name}</h1>
            
            <div className="flex items-center gap-4 mb-6">
              <StarRating rating={product.rating} count={product.reviewCount} />
              <div className="h-4 w-px bg-border"></div>
              <div className="text-sm text-muted-foreground flex items-center gap-1">
                <Check className="h-4 w-4 text-green-500" /> 
                {product.stock > 0 ? `In Stock (${product.stock})` : <span className="text-destructive">Out of Stock</span>}
              </div>
            </div>

            <div className="flex items-end gap-3 mb-8">
              <span className="text-4xl font-extrabold">${product.price.toFixed(2)}</span>
              {product.originalPrice && product.originalPrice > product.price && (
                <span className="text-xl text-muted-foreground line-through mb-1">${product.originalPrice.toFixed(2)}</span>
              )}
            </div>

            <p className="text-muted-foreground mb-8 text-lg leading-relaxed">
              {product.description || "Experience the pinnacle of craftsmanship and design. This premium product is carefully selected to ensure the highest quality standards for our discerning customers."}
            </p>
          </motion.div>

          <hr className="border-border mb-8" />

          {/* Actions */}
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="flex items-center border border-input rounded-md bg-background w-full sm:w-32 h-14">
              <button 
                className="px-4 h-full hover:bg-secondary/10 transition-colors rounded-l-md"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
              >-</button>
              <div className="flex-1 text-center font-semibold">{quantity}</div>
              <button 
                className="px-4 h-full hover:bg-secondary/10 transition-colors rounded-r-md"
                onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
              >+</button>
            </div>
            
            <Button 
              className="flex-1 h-14 text-lg font-bold rounded-xl shadow-[0_0_20px_-5px_hsl(var(--primary))] hover:shadow-[0_0_30px_-5px_hsl(var(--primary))] transition-all"
              onClick={handleAddToCart}
              disabled={product.stock === 0}
            >
              <ShoppingBag className="mr-2 h-5 w-5" />
              Add to Cart
            </Button>
            
            <Button variant="outline" size="icon" className="h-14 w-14 rounded-xl shrink-0 hover:text-primary hover:border-primary transition-colors" onClick={handleAddToWishlist}>
              <Heart className="h-6 w-6" />
            </Button>
          </motion.div>

          {/* Features */}
          <motion.div 
            className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-center gap-3 p-4 rounded-xl bg-card border border-border">
              <Truck className="h-6 w-6 text-primary" />
              <div>
                <div className="font-semibold">Free Delivery</div>
                <div className="text-xs text-muted-foreground">Orders over $50</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 rounded-xl bg-card border border-border">
              <RotateCcw className="h-6 w-6 text-primary" />
              <div>
                <div className="font-semibold">30 Days Return</div>
                <div className="text-xs text-muted-foreground">No questions asked</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 rounded-xl bg-card border border-border">
              <Package className="h-6 w-6 text-primary" />
              <div>
                <div className="font-semibold">Premium Packaging</div>
                <div className="text-xs text-muted-foreground">Signature box included</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 rounded-xl bg-card border border-border cursor-pointer hover:border-primary transition-colors">
              <Share2 className="h-6 w-6 text-primary" />
              <div>
                <div className="font-semibold">Share Product</div>
                <div className="text-xs text-muted-foreground">Spread the word</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Tabs / Details */}
      <div className="mb-24">
        <div className="border-b border-border flex gap-8 mb-8">
          <div className="border-b-2 border-primary pb-4 font-bold text-lg text-primary">Reviews ({reviews?.items?.length || 0})</div>
          <div className="pb-4 font-medium text-lg text-muted-foreground cursor-pointer hover:text-foreground">Specifications</div>
          <div className="pb-4 font-medium text-lg text-muted-foreground cursor-pointer hover:text-foreground">Seller Info</div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div className="md:col-span-2 space-y-8">
            {loadingReviews ? (
              <LoadingSpinner />
            ) : reviews?.items?.length === 0 ? (
              <p className="text-muted-foreground">No reviews yet. Be the first to review this product!</p>
            ) : (
              reviews?.items?.map((review) => (
                <div key={review.id} className="pb-8 border-b border-border">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-semibold text-lg">User {review.userId}</div>
                    <span className="text-sm text-muted-foreground">{new Date(review.createdAt).toLocaleDateString()}</span>
                  </div>
                  <StarRating rating={review.rating} />
                  <p className="mt-4 text-muted-foreground leading-relaxed">{review.comment}</p>
                </div>
              ))
            )}
          </div>
          
          <div className="bg-card p-6 rounded-2xl border border-border h-fit">
            <h3 className="font-bold text-xl mb-6">Write a Review</h3>
            <form onSubmit={handleReviewSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Rating</label>
                <div className="flex gap-2">
                  {[1,2,3,4,5].map(star => (
                    <button 
                      key={star} 
                      type="button" 
                      onClick={() => setReviewForm({...reviewForm, rating: star})}
                      className="focus:outline-none"
                    >
                      <StarRating rating={reviewForm.rating >= star ? 1 : 0} />
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Review</label>
                <Textarea 
                  placeholder="Share your thoughts about this product..."
                  className="resize-none h-32"
                  value={reviewForm.comment}
                  onChange={(e) => setReviewForm({...reviewForm, comment: e.target.value})}
                  required
                />
              </div>
              <Button type="submit" className="w-full">Submit Review</Button>
            </form>
          </div>
        </div>
      </div>

      {/* Related Products */}
      {recommendations && recommendations.length > 0 && (
        <section>
          <h2 className="text-3xl font-extrabold mb-8 tracking-tight">You Might Also Like</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {recommendations.slice(0, 4).map((rec, i) => (
              <motion.div
                key={rec.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <ProductCard product={rec} />
              </motion.div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}