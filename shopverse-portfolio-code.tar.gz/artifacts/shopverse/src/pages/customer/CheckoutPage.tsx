import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useGetCart, useCreateOrder } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Check, CreditCard, Wallet, Truck, ChevronRight } from "lucide-react";
import LoadingSpinner from "@/components/LoadingSpinner";
import { toast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export default function CheckoutPage() {
  const [, setLocation] = useLocation();
  const { data: cart, isLoading } = useGetCart();
  const createOrder = useCreateOrder();
  
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState("card");
  
  // Form state
  const [address, setAddress] = useState({
    firstName: "John",
    lastName: "Doe",
    email: "john@example.com",
    address: "123 Premium Blvd",
    city: "New York",
    zip: "10001",
    country: "USA"
  });

  if (isLoading) return <LoadingSpinner />;

  const cartItems = cart?.items || [];
  if (cartItems.length === 0 && step === 1) {
    setLocation("/cart");
    return null;
  }

  const subtotal = cartItems.reduce((acc, item) => {
    const price = (item.productId * 10) + 49.99; 
    return acc + (price * item.quantity);
  }, 0);
  const total = subtotal + 15; // shipping

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(step + 1);
  };

  const handlePlaceOrder = () => {
    // Format order items for API
    const items = cartItems.map(item => ({
      productId: item.productId,
      quantity: item.quantity,
      price: (item.productId * 10) + 49.99
    }));

    createOrder.mutate({
      data: {
        items,
        shippingAddress: `${address.address}, ${address.city}, ${address.zip}, ${address.country}`,
        paymentMethod
      }
    }, {
      onSuccess: () => {
        setStep(4); // Success step
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to place order", variant: "destructive" });
      }
    });
  };

  if (step === 4) {
    return (
      <div className="container mx-auto px-4 py-24 flex flex-col items-center justify-center text-center">
        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="w-24 h-24 bg-green-500/20 text-green-500 rounded-full flex items-center justify-center mb-6"
        >
          <Check className="h-12 w-12" />
        </motion.div>
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-4xl font-extrabold tracking-tight mb-4"
        >
          Order Confirmed!
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-muted-foreground text-lg mb-8 max-w-md"
        >
          Thank you for shopping with ShopVerse. Your premium products are being prepared for shipping.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="flex gap-4"
        >
          <Link href="/orders">
            <Button size="lg" variant="outline" className="rounded-full">View Order</Button>
          </Link>
          <Link href="/">
            <Button size="lg" className="rounded-full font-bold">Continue Shopping</Button>
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Checkout Steps */}
      <div className="flex items-center justify-center mb-12 max-w-2xl mx-auto">
        {[
          { num: 1, label: "Shipping" },
          { num: 2, label: "Payment" },
          { num: 3, label: "Review" }
        ].map((s, i) => (
          <div key={s.num} className="flex items-center">
            <div className={`flex flex-col items-center relative ${step >= s.num ? "text-primary" : "text-muted-foreground"}`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold mb-2 transition-colors
                ${step > s.num ? "bg-primary text-primary-foreground" : step === s.num ? "bg-primary/20 border-2 border-primary" : "bg-muted"}`}
              >
                {step > s.num ? <Check className="h-5 w-5" /> : s.num}
              </div>
              <span className="text-xs font-semibold uppercase tracking-wider absolute -bottom-6 whitespace-nowrap">{s.label}</span>
            </div>
            {i < 2 && (
              <div className={`w-16 sm:w-32 h-1 mx-2 sm:mx-4 rounded-full transition-colors ${step > s.num ? "bg-primary" : "bg-muted"}`} />
            )}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mt-16">
        <div className="lg:col-span-2">
          {/* Step 1: Shipping */}
          {step === 1 && (
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
              <h2 className="text-2xl font-bold tracking-tight mb-6">Shipping Information</h2>
              <form onSubmit={handleNextStep} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input id="firstName" value={address.firstName} onChange={e => setAddress({...address, firstName: e.target.value})} required className="bg-card" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input id="lastName" value={address.lastName} onChange={e => setAddress({...address, lastName: e.target.value})} required className="bg-card" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" value={address.email} onChange={e => setAddress({...address, email: e.target.value})} required className="bg-card" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Input id="address" value={address.address} onChange={e => setAddress({...address, address: e.target.value})} required className="bg-card" />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="col-span-1 space-y-2">
                    <Label htmlFor="zip">ZIP Code</Label>
                    <Input id="zip" value={address.zip} onChange={e => setAddress({...address, zip: e.target.value})} required className="bg-card" />
                  </div>
                  <div className="col-span-1 space-y-2">
                    <Label htmlFor="city">City</Label>
                    <Input id="city" value={address.city} onChange={e => setAddress({...address, city: e.target.value})} required className="bg-card" />
                  </div>
                  <div className="col-span-1 space-y-2">
                    <Label htmlFor="country">Country</Label>
                    <Input id="country" value={address.country} onChange={e => setAddress({...address, country: e.target.value})} required className="bg-card" />
                  </div>
                </div>
                <Button type="submit" size="lg" className="w-full sm:w-auto mt-4 font-bold">
                  Continue to Payment <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </form>
            </motion.div>
          )}

          {/* Step 2: Payment */}
          {step === 2 && (
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
              <h2 className="text-2xl font-bold tracking-tight mb-6">Payment Method</h2>
              <form onSubmit={handleNextStep}>
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-4">
                  <Label htmlFor="card" className={`flex items-center gap-4 p-4 border rounded-xl cursor-pointer transition-colors ${paymentMethod === 'card' ? 'border-primary bg-primary/5' : 'border-border bg-card'}`}>
                    <RadioGroupItem value="card" id="card" />
                    <CreditCard className="h-6 w-6 text-muted-foreground" />
                    <div className="flex-1">
                      <div className="font-semibold text-lg">Credit / Debit Card</div>
                      <div className="text-sm text-muted-foreground">Pay securely with your card</div>
                    </div>
                  </Label>
                  
                  <Label htmlFor="upi" className={`flex items-center gap-4 p-4 border rounded-xl cursor-pointer transition-colors ${paymentMethod === 'upi' ? 'border-primary bg-primary/5' : 'border-border bg-card'}`}>
                    <RadioGroupItem value="upi" id="upi" />
                    <Wallet className="h-6 w-6 text-muted-foreground" />
                    <div className="flex-1">
                      <div className="font-semibold text-lg">UPI / Razorpay</div>
                      <div className="text-sm text-muted-foreground">Google Pay, PhonePe, Paytm</div>
                    </div>
                  </Label>
                  
                  <Label htmlFor="cod" className={`flex items-center gap-4 p-4 border rounded-xl cursor-pointer transition-colors ${paymentMethod === 'cod' ? 'border-primary bg-primary/5' : 'border-border bg-card'}`}>
                    <RadioGroupItem value="cod" id="cod" />
                    <Truck className="h-6 w-6 text-muted-foreground" />
                    <div className="flex-1">
                      <div className="font-semibold text-lg">Cash on Delivery</div>
                      <div className="text-sm text-muted-foreground">Pay when your order arrives</div>
                    </div>
                  </Label>
                </RadioGroup>
                
                {paymentMethod === 'card' && (
                  <div className="mt-8 space-y-4 p-6 border border-border rounded-xl bg-card">
                    <div className="space-y-2">
                      <Label>Card Number</Label>
                      <Input placeholder="0000 0000 0000 0000" className="font-mono bg-background" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Expiry Date</Label>
                        <Input placeholder="MM/YY" className="bg-background" />
                      </div>
                      <div className="space-y-2">
                        <Label>CVC</Label>
                        <Input placeholder="123" className="bg-background" />
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex gap-4 mt-8">
                  <Button type="button" variant="outline" onClick={() => setStep(1)}>Back</Button>
                  <Button type="submit" size="lg" className="flex-1 font-bold">
                    Review Order <ChevronRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </form>
            </motion.div>
          )}

          {/* Step 3: Review */}
          {step === 3 && (
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
              <h2 className="text-2xl font-bold tracking-tight mb-6">Review Your Order</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-6 border border-border rounded-xl bg-card">
                  <h3 className="font-semibold text-lg mb-4 flex items-center justify-between">
                    Shipping Details
                    <Button variant="link" size="sm" onClick={() => setStep(1)} className="text-primary p-0 h-auto">Edit</Button>
                  </h3>
                  <div className="text-muted-foreground space-y-1">
                    <p className="font-medium text-foreground">{address.firstName} {address.lastName}</p>
                    <p>{address.address}</p>
                    <p>{address.city}, {address.zip}</p>
                    <p>{address.country}</p>
                    <p className="mt-2">{address.email}</p>
                  </div>
                </div>
                
                <div className="p-6 border border-border rounded-xl bg-card">
                  <h3 className="font-semibold text-lg mb-4 flex items-center justify-between">
                    Payment Method
                    <Button variant="link" size="sm" onClick={() => setStep(2)} className="text-primary p-0 h-auto">Edit</Button>
                  </h3>
                  <div className="text-muted-foreground flex items-center gap-3">
                    {paymentMethod === 'card' && <><CreditCard className="h-5 w-5"/> Credit Card ending in 4242</>}
                    {paymentMethod === 'upi' && <><Wallet className="h-5 w-5"/> UPI via Razorpay</>}
                    {paymentMethod === 'cod' && <><Truck className="h-5 w-5"/> Cash on Delivery</>}
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-4">Items ({cartItems.length})</h3>
                <div className="space-y-4">
                  {cartItems.map(item => {
                    const price = (item.productId * 10) + 49.99;
                    return (
                      <div key={item.id} className="flex items-center gap-4 p-4 border border-border rounded-xl bg-card">
                        <div className="w-16 h-16 bg-muted rounded-md overflow-hidden shrink-0">
                          <img src={`https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=100&q=80&sig=${item.productId}`} alt="Product" className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1">
                          <div className="font-semibold">Premium Product #{item.productId}</div>
                          <div className="text-sm text-muted-foreground">Qty: {item.quantity}</div>
                        </div>
                        <div className="font-bold">${(price * item.quantity).toFixed(2)}</div>
                      </div>
                    )
                  })}
                </div>
              </div>

              <div className="flex gap-4">
                <Button type="button" variant="outline" onClick={() => setStep(2)}>Back</Button>
                <Button size="lg" className="flex-1 font-bold shadow-[0_0_20px_-5px_hsl(var(--primary))]" onClick={handlePlaceOrder} disabled={createOrder.isPending}>
                  {createOrder.isPending ? <LoadingSpinner /> : "Place Order"}
                </Button>
              </div>
            </motion.div>
          )}
        </div>

        {/* Order Summary Sidebar */}
        <div className="lg:col-span-1">
          <div className="rounded-2xl border border-border bg-card p-6 sticky top-24">
            <h2 className="text-xl font-bold tracking-tight mb-6">Order Summary</h2>
            
            <div className="space-y-4 text-sm mb-6">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-semibold">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping estimate</span>
                <span className="font-semibold">$15.00</span>
              </div>
            </div>

            <div className="pt-4 border-t border-border">
              <div className="flex justify-between items-end">
                <span className="text-base font-bold">Total</span>
                <span className="text-3xl font-extrabold text-primary">${total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}