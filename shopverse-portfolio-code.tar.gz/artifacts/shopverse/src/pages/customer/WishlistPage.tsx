import { Link } from "wouter";
import { useGetWishlist, useRemoveFromWishlist } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Heart, Trash2 } from "lucide-react";
import LoadingSpinner from "@/components/LoadingSpinner";
import { toast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

export default function WishlistPage() {
  const { data: wishlist, isLoading } = useGetWishlist();
  const removeFromWishlist = useRemoveFromWishlist();

  if (isLoading) return <LoadingSpinner />;

  const wishlistItems = wishlist?.items || [];

  const handleRemove = (productId: number) => {
    removeFromWishlist.mutate({ data: { productId } }, {
      onSuccess: () => {
        toast({ title: "Removed from wishlist" });
      }
    });
  };

  if (wishlistItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 flex flex-col items-center justify-center min-h-[60vh] text-center">
        <div className="w-24 h-24 bg-secondary/10 rounded-full flex items-center justify-center mb-6">
          <Heart className="h-10 w-10 text-primary" />
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight mb-4">Your wishlist is empty</h1>
        <p className="text-muted-foreground mb-8 max-w-md">Save items you love to your wishlist. Review them anytime and easily move them to your cart.</p>
        <Link href="/products">
          <Button size="lg" className="rounded-full px-8 font-bold">
            Explore Products
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-extrabold tracking-tight">My Wishlist</h1>
        <span className="text-muted-foreground">{wishlistItems.length} items</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        <AnimatePresence>
          {wishlistItems.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ delay: i * 0.05 }}
              className="relative group bg-card border border-border rounded-xl overflow-hidden shadow-sm hover:shadow-2xl hover:shadow-primary/20 transition-all duration-300"
            >
              <div className="absolute top-3 right-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button 
                  variant="destructive" 
                  size="icon" 
                  className="h-8 w-8 rounded-full shadow-md"
                  onClick={(e) => {
                    e.preventDefault();
                    handleRemove(item.productId);
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>

              <Link href={`/products/${item.productId}`}>
                <div className="aspect-square w-full bg-muted">
                  <img src={`https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&q=80&sig=${item.productId}`} alt="Product" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-base line-clamp-1 group-hover:text-primary transition-colors">Premium Product #{item.productId}</h3>
                  <div className="mt-2 text-lg font-bold">${((item.productId * 10) + 49.99).toFixed(2)}</div>
                </div>
              </Link>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}