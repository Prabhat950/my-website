import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateProduct, useListCategories } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft } from "lucide-react";
import LoadingSpinner from "@/components/LoadingSpinner";

export default function AddProductForm() {
  const [, setLocation] = useLocation();
  const { data: categories } = useListCategories();
  const createProduct = useCreateProduct();

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    originalPrice: "",
    stock: "10",
    category: "",
    imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80",
    tags: "premium"
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createProduct.mutate({
      data: {
        name: formData.name,
        description: formData.description,
        price: parseFloat(formData.price),
        originalPrice: formData.originalPrice ? parseFloat(formData.originalPrice) : undefined,
        stock: parseInt(formData.stock, 10),
        category: formData.category,
        sellerId: 1, // Mock
        images: [formData.imageUrl],
        tags: formData.tags.split(",").map(t => t.trim())
      }
    }, {
      onSuccess: () => {
        toast({ title: "Product created successfully!" });
        setLocation("/seller/products");
      },
      onError: (err) => {
        toast({ title: "Failed to create product", variant: "destructive" });
      }
    });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => setLocation("/seller/products")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-extrabold tracking-tight">Add New Product</h1>
      </div>

      <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name">Product Name *</Label>
            <Input id="name" required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" className="h-32" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <Select required value={formData.category} onValueChange={v => setFormData({...formData, category: v})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {categories?.map(cat => (
                    <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="stock">Stock Quantity *</Label>
              <Input id="stock" type="number" required min="0" value={formData.stock} onChange={e => setFormData({...formData, stock: e.target.value})} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="price">Selling Price ($) *</Label>
              <Input id="price" type="number" step="0.01" required min="0" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="originalPrice">Original Price ($) (Optional)</Label>
              <Input id="originalPrice" type="number" step="0.01" min="0" value={formData.originalPrice} onChange={e => setFormData({...formData, originalPrice: e.target.value})} />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="imageUrl">Image URL *</Label>
            <Input id="imageUrl" required placeholder="https://..." value={formData.imageUrl} onChange={e => setFormData({...formData, imageUrl: e.target.value})} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags">Tags (comma separated)</Label>
            <Input id="tags" placeholder="premium, trending, new" value={formData.tags} onChange={e => setFormData({...formData, tags: e.target.value})} />
          </div>

          <div className="pt-4 flex justify-end gap-4 border-t border-border">
            <Button type="button" variant="outline" onClick={() => setLocation("/seller/products")}>Cancel</Button>
            <Button type="submit" disabled={createProduct.isPending} className="px-8 font-bold">
              {createProduct.isPending ? "Creating..." : "Create Product"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}